const fastify = require('fastify')({ logger: true })
const mysql = require('mysql2/promise')
require('dotenv').config()

fastify.register(require('@fastify/cors'), {
  origin: true
})

const dbConfig = {
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
}

const pool = mysql.createPool(dbConfig)

fastify.post('/api/torneo', async (request, reply) => {
  const { team, player, coach } = request.body
  const connection = await pool.getConnection()

  try {
    await connection.beginTransaction()

    fastify.log.info('Inserting team:', team)
    const [teamResult] = await connection.query(
      'INSERT INTO equipo (nombre, ciudad, anio_fundacion) VALUES (?, ?, ?)',
      [team.name, team.city, team.yearFounded]
    )
    const teamId = teamResult.insertId
    fastify.log.info('Team inserted, ID:', teamId)

    fastify.log.info('Inserting player:', player)
    await connection.query(
      'INSERT INTO jugador (nombre, apellido, posicion, equipo_id) VALUES (?, ?, ?, ?)',
      [player.firstName, player.lastName, player.position, teamId]
    )

    fastify.log.info('Inserting coach:', coach)
    await connection.query(
      'INSERT INTO entrenador (nombre, anios_experiencia, equipo_id) VALUES (?, ?, ?)',
      [coach.name, coach.experience, teamId]
    )

    await connection.commit()
    fastify.log.info('Transaction committed successfully')
    return { message: 'Datos creados exitosamente' }
  } catch (error) {
    await connection.rollback()
    fastify.log.error('Error in /api/torneo:', error)
    reply.status(500).send({ message: 'Error al crear datos', error: error.message })
  } finally {
    connection.release()
  }
})

fastify.setErrorHandler(function (error, request, reply) {
  fastify.log.error(error)
  reply.status(500).send({ message: 'Error interno del servidor', error: error.message })
})

const start = async () => {
  try {
    await fastify.listen({ port: process.env.PORT || 5000, host: '0.0.0.0' })
    fastify.log.info(`servidor escuchando en ${fastify.server.address().port}`)
  } catch (err) {
    fastify.log.error(err)
    process.exit(1)
  }
}

start()